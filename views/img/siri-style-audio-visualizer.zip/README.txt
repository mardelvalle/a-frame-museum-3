A Pen created at CodePen.io. You can find this one at https://codepen.io/fgnass/pen/LWeKNq.

 This pen uses the Web Audio API to access the microphone and visualize the input in a Siri-like fashion.